package edu.kh.jdbc.main.run;

import edu.kh.jdbc.main.view.MainView;

public class MainRun {
	public static void main(String[] args) {
		
		// 객체를 1회만 사용할 때 작성하는 방식
		new MainView().mainMenu();
		
	}
}
